/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadorabasica.ivettecardona;

/**
 *
 * @author LABORATORIO
 */
public class CalculadoraBasica10IvetteCardona {

    public static void main(String[] args) {
        jfrmCalc holaPos = new jfrmCalc();
        holaPos.setVisible(true);
    }
}
